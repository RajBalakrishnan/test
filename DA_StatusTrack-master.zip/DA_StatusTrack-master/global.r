library(RPostgreSQL)
library(data.table)
getConDB <- function(stmnt)
{drv = dbDriver("PostgreSQL")
  if (exists("con")) {dbDisconnect(con)}
  con <- dbConnect(drv, dbname = "reddaenrollment", host = "reddaanalyticspg.cngkcakawy89.us-west-1.rds.amazonaws.com",
                   port = 5432, user = "rbalakrishnan", password = "abc1234")
  result <- data.table(dbGetQuery(conn = con, statement = stmnt))
  dbDisconnect(con)
  return(result)
}
putConDB <- function(FrmData, TableName)
{drv = dbDriver("PostgreSQL")
  if (exists("con")) {dbDisconnect(con)}
  con <- dbConnect(drv, dbname = "reddaenrollment", host = "reddaanalyticspg.cngkcakawy89.us-west-1.rds.amazonaws.com",
                   port = 5432, user = "rbalakrishnan", password = "abc1234")
  dbWriteTable(con, TableName, FrmData, append = TRUE, row.names = FALSE)
  dbDisconnect(con)
}