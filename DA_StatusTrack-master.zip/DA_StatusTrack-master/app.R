for (package in c('shiny','shinyBS', 'DT','data.table', 'tibble', 'shinyjs', 'diagram', 'shape', 'rhandsontable', 
                  'httr', 'lattice','dplyr','DBI', 'RPostgreSQL')) {
  if (!require(package, character.only = T, quietly = T)) { #install.packages(package)
    suppressWarnings(suppressMessages(library(package, character.only = T)))
  }
}

getConDB <- function(stmnt)
{drv = dbDriver("PostgreSQL")
if (exists("con")) {dbDisconnect(con)}
con <- dbConnect(drv, dbname = "reddaenrollment", host = "reddaanalyticspg.cngkcakawy89.us-west-1.rds.amazonaws.com",
                 port = 5432, user = "rbalakrishnan", password = "abc1234")
result <- data.table(dbGetQuery(conn = con, statement = stmnt))
dbDisconnect(con)
return(result)
}

WFUpdateConDB <- function(FrmData, stmnt)
{drv = dbDriver("PostgreSQL")
if (exists("con")) {dbDisconnect(con)}
con <- dbConnect(drv, dbname = "reddaenrollment", host = "reddaanalyticspg.cngkcakawy89.us-west-1.rds.amazonaws.com",
                 port = 5432, user = "rbalakrishnan", password = "abc1234")
outp <- dbSendQuery(conn = con, statement = stmnt)
dbWriteTable(con, "wfstatus", FrmData, append = TRUE, row.names = FALSE)
dbDisconnect(con)
}
options(shiny.maxRequestSize = 30*1024^2)
querySel5 <- sqlInterpolate(ANSI(),'select DISTINCT t."AssayTypes" FROM public."Assays" t;')
Assays <-  as.data.frame(getConDB(querySel5))
querySel1 <- sqlInterpolate(ANSI(),'SELECT * FROM public."solrOODFM" ORDER BY "DataAssetNumber" DESC;')
solrOODFM <-  getConDB(querySel1)
querySel1 <- sqlInterpolate(ANSI(),'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY "DA_Number" ORDER BY "Accession_Number" DESC) rn FROM public."SData_Prod")
                            tmp WHERE rn = 1 and "DA_Number" IN (SELECT DISTINCT "DA_Number" FROM public."SData_Prod") ORDER BY "DA_Number" DESC;')
StudyData <- as.data.frame(getConDB(querySel1))
danum <-  StudyData$DA_Number
querySel1 <- sqlInterpolate(ANSI(),'SELECT * FROM public."AData_Prod" WHERE "DA_NumberVal" IN (SELECT DISTINCT "DA_Number" FROM public."SData_Prod") AND "Accession_Number" in
                            (SELECT "Accession_Number" FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY "DA_Number" ORDER BY "Accession_Number" DESC) rn FROM public."SData_Prod")
                            tmp WHERE rn = 1 and "DA_Number" IN (SELECT DISTINCT "DA_Number" FROM public."SData_Prod") ORDER BY "DA_Number" DESC) ORDER BY "DA_NumberVal" DESC;')
AssayData <- as.data.frame(getConDB(querySel1))
querySel1 <- sqlInterpolate(ANSI(),'SELECT * FROM public."wfstatus" ORDER BY "DA_Number" DESC;')
wfstatus <-  as.data.frame(getConDB(querySel1), stringsAsFactors = FALSE)
solrOODFM$DA_Number <- solrOODFM$DataAssetNumber

ui <- shinyUI(fluidPage(shinyjs::useShinyjs(), title = "REF Viewer & DA Tracker",tags$style(" body {zoom: 70%}"),
                        titlePanel(tags$img(src = 'Title.png', height = 65, width = 1000)),
                        sidebarLayout(sidebarPanel(
                          conditionalPanel(condition = "input.tabselected==1|input.tabselected==2|input.tabselected==3",
                                           selectInput(inputId = "filterDANUM", label = h5(strong(span("Select a DA Number", style = "color:brown"))),multiple = F,
                                                       choices = sort(StudyData$DA_Number, decreasing = TRUE), selected = "")),
                          conditionalPanel(condition = "input.tabselected==2",
                                           h4(strong(tags$u(span("Update DA Tracking Info", style = "color:black")))),
                                           selectInput("AssayList", label = "Select an Assay", choices = "", selected = ""),
                                           selectInput("BatchInfo", label = "Data Batch Information", choices = "", selected = ""),
                                           actionButton("OpenManifest", "View Manifest Info",style = "color: #fff; background-color:FORESTGREEN; border-color: #2e6da4"),
                                           selectInput("DataSource", label = "Data Source", choices = c("","Celgene Employees","Non-Celgene Collaborators", "Vendor", "Public Data/Source"), selected = ""),
                                           selectInput("S3DT", label = "S3-redda-datatransfer status", choices = c("Data being appended / Process in-progress" = "P",
                                                                                                                   "Data Available /Process completed" = "C","Waiting for Data / Process not-started" = "W","Error Fixing" = "E","Skipped" = "S"),selected = ""),
                                           selectInput("S3Src", label = "S3-celgene-src status", choices = c("Data being appended / Process in-progress" = "P", "Data Available /Process completed" = "C",
                                                                                                             "Waiting for Data / Process not-started" = "W","Error Fixing" = "E"), selected = ""),
                                           selectInput("s3riku", label = "S3-rnd-riku status",choices = c("Data being appended / Process in-progress" = "P", "Data Available /Process completed" = "C",
                                                                                                          "Waiting for Data / Process not-started" = "W","Error Fixing" = "E","Skipped" = "S"), selected = ""),
                                           selectInput("Cura", label = "Metadata Curation status", choices = c("Data being appended / Process in-progress" = "P", "Data Available /Process completed" = "C",
                                                                                                               "Waiting for Data / Process not-started" = "W","Error Fixing" = "E"), selected = ""),
                                           selectInput("Ingest", label = "Files Ingestion status", choices = c("Data being appended / Process in-progress" = "P", "Data Available /Process completed" = "C",
                                                                                                               "Waiting for Data / Process not-started" = "W","Error Fixing" = "E"), selected = ""),
                                           selectInput("LK", label = "LabKey status", choices = c("Data being appended / Process in-progress" = "P", "Data Available /Process completed" = "C",
                                                                                                  "Waiting for Data / Process not-started" = "W","Error Fixing" = "E","Skipped" = "S"), selected = ""),
                                           selectInput("MF", label = "Manifest status", choices = c("Waiting for Data / Process not-started" = "W", "Data Available /Process completed" = "C",
                                                                                                    "Data being appended / Process in-progress" = "P","Error Fixing" = "E","NA / Skipped" = "S"), selected = ""),
                                           textAreaInput("StatusSummary", label = "REDDA Workflow Notes", value = " ", width = NULL, height = NULL, cols = NULL, rows = 2,
                                                         placeholder = "Max 300 characters", resize = "vertical"),br(),
                                           actionButton("DataStatus", "Update Tracking Info",style = "color: #fff; background-color:FORESTGREEN; border-color: #2e6da4")), #conditionalPanel ends
                          
                          conditionalPanel(condition = "input.tabselected==3" , 
                                           numericInput("AddRow", "Row(s) to add", value = 0, min = 0, max = 5, step = 1,width = "150"),br(),
                                           actionButton("SaveTLD", "Save TimeLine Table",style = "color: #fff; background-color:RoyalBlue; border-color: #2e6da4"))
                          , width = 2),
                          
                          mainPanel(wellPanel( tabsetPanel(type = "pills", id = "tabselected",
                                                           tabPanel("Study Information", value = 1,
                                                                    tags$link(rel = "stylesheet", type = "text/css",href = "style.css"), tags$script(type = "text/javascript", src = "busy.js"),
                                                                    DT::dataTableOutput("SDtable", width = "auto", height = "auto"),
                                                                    DT::dataTableOutput("Assay1", width = "auto", height = "auto"),
                                                                    div(class = "busy", h4(strong(span("Loading/Processing data....!", style = "color:blue"))), img(src = "Processing.gif"))
                                                                    ,style = "overflow-y:scroll; max-height: 950px"),
                                                           
                                                           tabPanel("REDDA Data Workflow Status", value = 2,
                                                                    tags$link(rel = "stylesheet", type = "text/css",href = "style.css"), tags$script(type = "text/javascript", src = "busy.js"),
                                                                    plotOutput("wfPlot",width = "100%", height = "900px"),
                                                                    bsModal("SampleManifest", "Sample Manifest", "OpenManifest", size = "large",dataTableOutput("SMTable")),
                                                                    div(class = "busy", h4(strong(span("Loading & Processing data....!", style = "color:blue"))), img(src = "Processing.gif"))
                                                                    ,style = "overflow-y:scroll; max-height: 950px"),
                                                           
                                                           tabPanel("Timelines", value = 3,
                                                                    tags$link(rel = "stylesheet", type = "text/css",href = "style.css"), tags$script(type = "text/javascript", src = "busy.js"),
                                                                    rHandsontableOutput("TLDates", width = "auto", height = "900px"),
                                                                    bsModal("modalExample", "REDDA Metrics", "PlotChart", size = "large",
                                                                            plotOutput("MetricsPlot")),
                                                                    div(class = "busy", h4(strong(span("Loading & Processing data....!", style = "color:blue"))), img(src = "Processing.gif"))
                                                                    ,style = "overflow-y:scroll; max-height: 950px")
                          )))
                        )))

server <- shinyServer(
  
  function(input, output, session){ #session$onSessionEnded(stopApp)
    hide("DataSource");hide("S3DT"); hide("S3Src");hide("s3riku");  hide("Cura"); #hide ("SaveTLD")
    
    hide("Ingest");  hide("LK"); hide("MF"); hide("StatusSummary");  hide("DataStatus")
    
    PlotUpdate <- function() {openplotmat()
      # print("AssayList---------------")
      # print(input$AssayList)
      # print("AssayList---------------")
      StatData <- dplyr::filter(wfstatus, grepl(input$filterDANUM,wfstatus$DA_Number))
      DAL <- dplyr::filter(StatData, StatData$AList == input$AssayList)
      DAL <- dplyr::filter(DAL , DAL$BatchInfo == input$BatchInfo)
      DAL <- DAL[order(DAL$ASSAYS),]
      if (nrow(DAL) < 1 ) {return()}
      updateSelectInput(session, "DataSource",selected = DAL$DATASRC[1])
      updateSelectInput(session, "S3DT",selected = DAL$S3RDTF[1])
      updateSelectInput(session, "S3Src",selected = DAL$S3SRCF[1])
      updateSelectInput(session, "s3riku",selected = DAL$RIKU[1])
      updateSelectInput(session, "Cura",selected = DAL$MDCURA[1])
      updateSelectInput(session, "Ingest",selected = DAL$INGEST[1])
      updateSelectInput(session, "LK",selected = DAL$LABKEY[1])
      updateSelectInput(session, "MF",selected = DAL$FSTATUS[1])
      updateTextAreaInput(session, "StatusSummary",value = DAL$SUMMARY[1])
      legend("topright", lwd = 11, cex = 1.2, legend = c("Waiting for Data / Process Not Started", "Data being appended / Process In-progress",
                                                         "Data Available / Process completed", "Error Fixing", "Not-Applicable / Skipped"),
             col = c("darkred", "gold", "DarkGreen", "chocolate3", "gray90"))
      elpos <- coordinates(c(1,3,4,1,1))
      fromto <- matrix(ncol = 2, byrow = TRUE, data = c(1,2, 1,3, 2,3, 3,4, 3,4, 3,7, 7,3, 8,3, 8,4))
      nr <- nrow(fromto); z = 1;  arrpos <- matrix(ncol = 2, nrow = nr)
      for (i in 1:nr) {arrpos[i, ] <- straightarrow(to = elpos[fromto[i, 2], ],from = elpos[fromto[i, 1], ], lwd = 3, arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$S3RDTF[z] == "S") {straightarrow(from = elpos[1,], to = elpos[2,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)
        textplain(mid = c(0.56,0.80), lab  = "Data transferred\n from other source", height = 0.2, cex = 1.5, col = 'darkblue', font = 2)
        straightarrow(from = elpos[2,], to = elpos[3,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$S3RDTF[z] != "S")
      {straightarrow(from = elpos[1,], to = elpos[3,], lwd = 3, lty = 1, lcol = 'white', arr.col = 'white', arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$RIKU[z] == "S") {straightarrow(from = elpos[3,], to = elpos[4,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      straightarrow(from = elpos[6,], to = elpos[3,], lwd = 3, lty = 3, arr.pos = 0.5, arr.length = 0.5)
      if (DAL$RIKU[z] == "S" ) {straightarrow(from = elpos[8,], to = elpos[4,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$LABKEY[z] == "S") {straightarrow(from = elpos[7,], to = elpos[3,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$LABKEY[z] == "S") {straightarrow(from = elpos[3,], to = elpos[7,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$FSTATUS[z] == "S" ) {straightarrow(from = elpos[8,], to = elpos[4,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      if (DAL$FSTATUS[z] == "S" ) {straightarrow(from = elpos[8,], to = elpos[3,], lwd = 3, lty = 1, lcol = "gray90", arr.col = "gray90", arr.pos = 0.55, arr.length = 0.5)}
      textplain(mid = c(0.18,0.98), lab  = DAL$AsyTyp[z], height = 0.2, cex = 1.5, col = 'darkgreen', font = 2)
      if (is.na(DAL$CTYN[1])) {DAL$CTYN[1] <- "No"}
      if (DAL$CTYN[1] == "Yes") {textplain(mid = c(0.14,0.88), lab  = paste("CT-ID: ",DAL$CTID[1], sep = " ") , height = 0.2, cex = 1.5, col = 'darkviolet', font = 2)}
      textplain(mid = c(0.85,0.82), lab  = paste("Data Receipt:",DAL$Data_Generation,sep = " "),  height = 0.2, cex = 1.5, col = 'blue', font = 2)
      ######"Data Source"######
      DataSrc <- gsub(" ", "\n", DAL$DATASRC[z])
      textellipse(elpos[1,], rady = 0.05, radx = 0.05*length(DAL$DATASRC[z]), lab = DataSrc, box.col = "rosybrown1",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5)
      ######"data-transfer"######
      if (DAL$S3RDTF[z] == "C") {textrect(elpos[2,], 0.1, 0.05,lab = "Celgene\nData Receiver", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$S3RDTF[z] == "W") {textrect(elpos[2,], 0.1, 0.05,lab = "Celgene\nData Receiver", box.col = "darkred",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$S3RDTF[z] == "E") {textrect(elpos[2,], 0.1, 0.05,lab = "Celgene\nData Receiver", box.col = "chocolate3",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$S3RDTF[z] == "P") {textrect(elpos[2,], 0.1, 0.05,lab = "Celgene\nData Receiver", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$S3RDTF[z] == "S") {textrect(elpos[2,], 0.1, 0.05,lab = "Celgene\nData Receiver", box.col = "gray90",shadow.col = "gray30",  shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2)}
      textplain(mid = c(0.17,0.62), lab  = DAL$Data_Received[z] , height = 0.2, cex = 1.5, col = 'blue', font = 1)
      ######"celgene-src bucket"######
      if (DAL$S3SRCF[z] == "C") {textrect(elpos[3,], 0.11, 0.05,lab = "REDDA repository", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$S3SRCF[z] == "W") {textrect(elpos[3,], 0.11, 0.05,lab = "REDDA repository",box.col = "darkred",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$S3SRCF[z] == "P") {textrect(elpos[3,], 0.11, 0.05,lab = "REDDA repository", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$S3SRCF[z] == "E") {textrect(elpos[3,], 0.11, 0.05,lab = "REDDA repository", box.col = "chocolate3",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$S3SRCF[z] == "S") {textrect(elpos[3,], 0.11, 0.05,lab = "REDDA repository", box.col = "gray90",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2)}
      textplain(mid = c(0.5,0.62), lab  = DAL$Data_in_REDDA[z], height = 0.2, cex = 1.5, col = 'blue', font = 1)
      ######"celgene-rnd-riku"######
      if (DAL$RIKU[z] == "C") {textrect(elpos[4,], 0.1, 0.05,lab = "Research Analytics\n[Bioinformatics]", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2) }
      if (DAL$RIKU[z] == "S") {textrect(elpos[4,], 0.1, 0.05,lab = "Research Analytics\n[Bioinformatics]", box.col = "gray90",shadow.col = "gray30",  shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2) }
      if (DAL$RIKU[z] == "W") {textrect(elpos[4,], 0.1, 0.05,lab = "Research Analytics\n[Bioinformatics]",box.col = "darkred",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$RIKU[z] == "P") {textrect(elpos[4,], 0.1, 0.05,lab = "Research Analytics\n[Bioinformatics]",box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      textplain(mid = c(0.8,0.62), lab  = DAL$Delivered_to_Scientists[z] , height = 0.2, cex = 1.5, col = 'blue', font = 1)
      ######"Data Curation"######
      if (DAL$MDCURA[z] == "W") {textdiamond(elpos[5,], 0.1, 0.07,lab = "Curation\nProcess", box.col = "darkred", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$MDCURA[z] == "P") {textdiamond(elpos[5,], 0.1, 0.07,lab = "Curation\nProcess", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$MDCURA[z] == "C") {textdiamond(elpos[5,], 0.1, 0.07,lab = "Curation\nProcess", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$MDCURA[z] == "E") {textdiamond(elpos[5,], 0.1, 0.07,lab = "Curation\nProcess", box.col = "chocolate3", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$MDCURA[z] == "S") {textdiamond(elpos[5,], 0.1, 0.07,lab = "Curation\nProcess", box.col = "gray90", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2)}
      ######"REDDA Archive"######
      if (DAL$INGEST[z] == "W") {textdiamond(elpos[6,], 0.1, 0.08, lab = "REDDA\nfiles\ningestion", box.col = "darkred",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$INGEST[z] == "P") {textdiamond(elpos[6,], 0.1, 0.08, lab = "REDDA\nfiles\ningestion", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$INGEST[z] == "C") {textdiamond(elpos[6,], 0.1, 0.08, lab = "REDDA\nfiles\ningestion", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$INGEST[z] == "E") {textdiamond(elpos[6,], 0.1, 0.08, lab = "REDDA\nfiles\ningestion", box.col = "chocolate3",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$INGEST[z] == "S") {textdiamond(elpos[6,], 0.1, 0.08, lab = "REDDA\nfiles\ningestion", box.col = "gray90",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2)}
      ######"LabKey"######
      if (DAL$LABKEY[z] == "W") {textdiamond(elpos[7,], 0.1, 0.07, lab  = "LabKey",box.col = "darkred",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$LABKEY[z] == "P") {textdiamond(elpos[7,], 0.1, 0.07, lab  = "LabKey", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$LABKEY[z] == "C") {textdiamond(elpos[7,], 0.1, 0.07, lab  = "LabKey", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$LABKEY[z] == "E") {textdiamond(elpos[7,], 0.1, 0.07, lab  = "LabKey", box.col = "chocolate3",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$LABKEY[z] == "S") {textdiamond(elpos[7,], 0.1, 0.07, lab  = "LabKey", box.col = "gray90",shadow.col = "gray30",  shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2) }
      ######"Manifest"######
      if (DAL$FSTATUS[z] == "W") {textdiamond(elpos[8,], 0.1, 0.07,lab = "Sample\nManifest", box.col = "darkred", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$FSTATUS[z] == "P") {textdiamond(elpos[8,], 0.1, 0.07,lab = "Sample\nManifest", box.col = "gold",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'black', font = 2)}
      if (DAL$FSTATUS[z] == "C") {textdiamond(elpos[8,], 0.1, 0.07,lab = "Sample\nManifest", box.col = "DarkGreen",shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$FSTATUS[z] == "E") {textdiamond(elpos[8,], 0.1, 0.07,lab = "Sample\nManifest", box.col = "chocolate3", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5, col = 'white', font = 2)}
      if (DAL$FSTATUS[z] == "S") {textdiamond(elpos[8,], 0.1, 0.07,lab = "Sample\nManifest", box.col = "gray90",shadow.col = "gray30",  shadow.size = 0.005, cex = 1.5, col = 'gray50', font = 2)}
      ######"Status Summary"######
      Summary = strwrap(DAL$SUMMARY[z], width = 100)
      textrect(elpos[9,], radx = 0.6, 0.03*length(Summary), lab = Summary,  box.col = "ivory", shadow.col = "gray30", shadow.size = 0.005, cex = 1.5)
      ######"Workflow Status"######
      StatusText <- paste("REDDA workflow status updated on\n", "[", DAL$StatusAt[z], "]", sep = "")
      textplain(elpos[10,], lab  = StatusText , height = 0.2, cex = 1.5)
    }
    
    
    SDetail <-  reactive(as.data.frame(getConDB(sqlInterpolate(ANSI(),'SELECT * FROM (SELECT *, ROW_NUMBER() OVER (PARTITION BY "DA_Number" ORDER BY "Accession_Number" DESC) rn FROM public."SData_Prod") tmp WHERE rn = 1 and "DA_Number" = ?id;', id = input$filterDANUM)), stringsAsFactors = FALSE))
    
    observeEvent(input$filterDANUM, {
      SDetail <- dplyr::filter(StudyData, grepl(input$filterDANUM,StudyData$DA_Number))
      ADetail <- dplyr::filter(AssayData, grepl(input$filterDANUM,AssayData$DA_NumberVal))
      ADetail <- ADetail[order(ADetail$AList),]
      updateSelectInput(session, "AssayList", choices = ADetail$AList)
      StatData <- dplyr::filter(wfstatus, grepl(input$filterDANUM,wfstatus$DA_Number))
      DAL <- dplyr::filter(StatData, StatData$AList == input$AssayList)
      DAL <- DAL[order(DAL$ASSAYS),]
      updateSelectInput(session, "BatchInfo", choices = DAL$BatchInfo)
    })
    
    observeEvent(input$AssayList, {
      StatData <- dplyr::filter(wfstatus, grepl(input$filterDANUM,wfstatus$DA_Number))
      DAL <- dplyr::filter(StatData, StatData$AList == input$AssayList)
      updateSelectInput(session, "BatchInfo", choices = DAL$BatchInfo)
    })
    
    unfactorize <- function(df){
      for (i in which(sapply(df, class) == "factor")) df[[i]] = as.character(df[[i]])
      return(df)
    }
    
    output$TLDates <- renderRHandsontable({

      wfstatus <- wfstatus[order(wfstatus$DA_Number, decreasing = TRUE), colnames(wfstatus)]
      wfstatus2 <- dplyr::filter(wfstatus, wfstatus$DA_Number == input$filterDANUM)
      wfstatus2 <- wfstatus2[order(wfstatus2$AList),]
      if (nrow(wfstatus2)>=1)   {row.names(wfstatus2) <-  paste(seq(1,nrow(wfstatus2), by = 1))}

      if(input$AddRow >=1) {
        wfnr <- data.frame(matrix(data = "", nrow = input$AddRow, ncol = 24, byrow = FALSE, dimnames = NULL),stringsAsFactors = FALSE)
        colnames(wfnr) <- c("ASSAYS", "AList", "DA_Number", "DATASRC", "S3RDTF", "S3SRCF", "RIKU", "MDCURA", "INGEST", "LABKEY", "FSTATUS", 
                             "SUMMARY", "StatusAt", "CTYN", "CTID", "BatchInfo", "AsyTyp", "Study_Registered", 
                             "Data_Received", "Data_in_REDDA", "Delivered_to_Scientists", "Accession_Number", "JIRA", "Data_Generation")
        unfactorize(wfnr)
        wfnr$Accession_Number <- as.integer(as.numeric(as.character(wfnr$Accession_Number)))
        wfstatus2 <- bind_rows(wfstatus2,wfnr)
        rownames(wfstatus2) <- paste(seq(1,nrow(wfstatus2), by = 1))
      }

      mdat <- data.frame(matrix(c("C", "C","E","E","S","P","P","W","W",""), 5, 2, byrow = TRUE,dimnames = list(c(1,2,3,4,5),c("C1", "C2"))))
      rhandsontable(wfstatus2, stretchH = "all", selectCallback = TRUE,readOnly = NULL) %>% hot_rows(rowHeights = 30)%>%
        hot_col(col = "S3RDTF", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE)) %>%
        hot_col(col = "S3SRCF", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "RIKU", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "MDCURA", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "LABKEY", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "INGEST", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "FSTATUS", type = "dropdown", strict = FALSE, source = sort(unique(mdat$C1), decreasing = FALSE))%>%
        hot_col(col = "AsyTyp", type = "dropdown", strict = FALSE, source = sort(unique(Assays$AssayTypes), decreasing = FALSE)) %>%  
        hot_col(col = "JIRA", renderer = "html") %>%
        hot_col(col = "JIRA", renderer = htmlwidgets::JS("safeHtmlRenderer"))
    })
    
    

    observeEvent(input$SaveTLD, {
      querySel <- sqlInterpolate(ANSI(),'DELETE FROM public."wfstatus" WHERE "DA_Number" = ?DNUM;', DNUM = input$filterDANUM)
      wfstatusdb <- unfactorize(hot_to_r(input$TLDates))
      wfstatusdb <- wfstatusdb[order(wfstatusdb$AList),]
      wfstatusdb$StatusAt  <- format(Sys.time(), "%a %b %d %X %Y")
      WFUpdateConDB(wfstatusdb,querySel)
      alert("Data updated in database table!")
    })
    
    output$wfPlot <- renderPlot({
      StatData <- dplyr::filter(wfstatus, grepl(input$filterDANUM,wfstatus$DA_Number))
      DAL <- dplyr::filter(StatData, grepl(input$AssayList,StatData$AList, fixed = TRUE))
      DAL <- dplyr::filter(DAL, grepl(input$BatchInfo,DAL$BatchInfo, fixed = TRUE))
      PlotUpdate()
    })
    
    output$SDtable <- DT::renderDataTable({
      SDetail <- dplyr::filter(StudyData, grepl(input$filterDANUM,StudyData$DA_Number))
      SDetail <- t(SDetail)
      colnames(SDetail) <- "Study Details"
      DT::datatable(SDetail, extensions = c('FixedColumns', 'FixedHeader'),rownames = TRUE,
                    options = list(pageLength = 16, deferRender = TRUE,  scrollY = "700px",scrollX = TRUE,
                                   scrollCollapse = TRUE, dom = 't', fixedColumns = TRUE, fixedHeader = TRUE)) %>%
        formatStyle(0,  color = 'yellow', backgroundColor = '#5f5f5f', fontWeight = 'bold',  width = '250px') %>%
        formatStyle(1,  fontWeight = 'bold') %>% formatStyle(colnames(SDetail), fontWeight = 'bold')
    })
    
    output$Assay1 <- DT::renderDataTable({
      SDetail <- dplyr::filter(StudyData, grepl(input$filterDANUM,StudyData$DA_Number))
      ADetail <- dplyr::filter(AssayData, grepl(input$filterDANUM,AssayData$DA_NumberVal))
      ADetail <- ADetail[order(as.numeric(ADetail$Assay_Number)),]
      ADetail <- ADetail[, -c(2, 3, 4, 7, 8, 13:15, 20:22, 30:38)]
      ADetail <- t(ADetail)
      colnames(ADetail) <- paste0(seq(1:SDetail$Number_Of_Assays))
      DT::datatable(ADetail, rownames = TRUE, class = 'cell-border stripe', #extensions = c('FixedColumns', 'FixedHeader', 'Scroller'),
                    options = list(pageLength = nrow(ADetail),  scrollY = "900px", deferRender = TRUE,  scrollX = TRUE, scrollCollapse = TRUE, scroller = TRUE,
                                   dom = 't',fixedColumns = TRUE, fixedHeader = TRUE)) %>%
        formatStyle(0,  color = 'yellow', backgroundColor = '#5f5f5f', fontWeight = 'bold', width = '250px') %>%
        formatStyle(colnames(ADetail), fontWeight = 'bold')
    })
    
    output$SMTable <- DT::renderDataTable({
      
      querySel <- sqlInterpolate(ANSI(),'SELECT * FROM public."MData_Prod" WHERE "DA_Number" = ?id AND "Assay_Type" = ?id2 AND "Batch_Info" = ?id3;',
                                 id = input$filterDANUM, id2 = sub(".*\\[(.*)\\].*", "\\1", input$AssayList, perl=TRUE), id3 = input$BatchInfo)
      mfinfo <- unique(as.data.frame(getConDB(querySel), stringsAsFactors = FALSE))
      DT::datatable(mfinfo, options = list(pageLength = nrow(mfinfo), deferRender = TRUE,  scrollY = "700px",scrollX = TRUE,
                                           scrollCollapse = TRUE, dom = 't', fixedColumns = TRUE, fixedHeader = TRUE))
    })
  })
shinyApp(ui = ui, server = server)


